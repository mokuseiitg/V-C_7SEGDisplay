/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.65
        Device            :  PIC16F1823
        Driver Version    :  2.00
*/

/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include "mcc_generated_files/mcc.h"
#include "mcp23017_driver.h"

//==============================================================================
// シリアル通信用
//==============================================================================
// 文字列送信
void putstr(char *str)
{
	while(*str != NULL)
	{
		EUSART_Write(*str++);
	}
}


//==============================================================================
// 7SEGLED 表示用
//==============================================================================
// 表示用変数
uint8_t d_step = 0;		// ダイナミック点灯シーケンス
uint8_t k_step = 0;		// 表示桁 電流1234-電圧1234

typedef union{
	struct{
		uint8_t vd[4];		// 表示する数字 電圧　BCD
		uint8_t cd[4];		// 表示する数字 電流　BCD
	};
	uint8_t bcd[8];			// 表示する数字
}_seg_data;
_seg_data segData;			// 表示データ
		
const uint8_t segTable[24] ={
	//.abcdefg
	0b01111110,		// 0
	0b00110000,		// 1
	0b01101101,		// 2
	0b01111001,		// 3
	0b00110011,		// 4
	0b01011011,		// 5
	0b00011111,		// 6
	0b01110000,		// 7
	0b01111111,		// 8
	0b01110011,		// 9
	0b00000000,		// X  10
	0b00000001,		// -  11
	0b11111110,		// 0. 12 (0+12)
	0b10110000,		// 1. 13
	0b11101101,		// 2. 14
	0b11111001,		// 3. 15
	0b10110011,		// 4. 16
	0b11011011,		// 5. 17
	0b10011111,		// 6. 18
	0b11110000,		// 7. 19
	0b11111111,		// 8. 20
	0b11110011,		// 9. 21
	0b10000000,		// X. 22
	0b10000001};	// -. 23

void SEG7_Drive()
{
	switch(d_step)
	{
		case 1:		// 点灯
			k_step++;
			k_step&=0x07;
				
			MCP17REG0.OLATB = ~(0x01 << k_step);									// 桁指定
			MCP17REG0.OLATA = segTable[segData.bcd[k_step]];			// 数字表示
			MCP17_pin_out();
			
			TMR0_Reload();
			INTCONbits.TMR0IF = 0;
			d_step++;
			break;
			
		case 2:		// ウェイト
			if(INTCONbits.TMR0IF != 0)
			{
				d_step++;
			}
			break;
		default:	// 消灯
			MCP17REG0.OLATB = 0xFF;	// 桁指定なし
			MCP17REG0.OLATA = 0x00; // 表示なし
			MCP17_pin_out();
			d_step=1;
			break;
	}
	
}


//==============================================================================
// 10進数変換
//==============================================================================
// 4桁BCD変換用構造体
typedef union{
	struct
	{
		uint16_t bin;
		uint8_t bcd0 : 4;
		uint8_t bcd1 : 4;
		uint8_t bcd2 : 4;
		uint8_t bcd3 : 4;
	};
	uint32_t data;
}_BCDtemp;

//　変換用一時データ
_BCDtemp bcdConvData;

// 16bitデータを4桁BCDデータに変換
void BCD_s22_conv(uint16_t data)
{
	bcdConvData.data = 0;
	bcdConvData.bin = data;
		
    for(uint8_t i = 0; i < 16; i++) {
        if(bcdConvData.bcd0 >= 5) bcdConvData.bcd0 += 3;
        if(bcdConvData.bcd1 >= 5) bcdConvData.bcd1 += 3;
        if(bcdConvData.bcd2 >= 5) bcdConvData.bcd2 += 3;
        if(bcdConvData.bcd3 >= 5) bcdConvData.bcd3 += 3;
        bcdConvData.data <<= 1;
    }
}


// 小数2桁の固定小数点データを10進文字列に変換する
// -nn.nn\0 の7バイト必要
char *BCD_s22_str_conv(int16_t data, char *str)
{
	// _BCDtemp *temp;
	char *p = str;
	int8_t sign = 0;
	if(data < 0 ){ 
		data = -data;
		sign =1;
	}
	
	// BCD変換
	BCD_s22_conv(data);
	
	// 文字列変換
	if(sign != 0)
	{	// マイナス
		*p++ = '-';
	}
	else
	{	// プラス
		*p++ = ' ';
	}
	*p = bcdConvData.bcd3 + '0';
	if(*p == '0') *p = ' ';
	p++;
	*p++ = bcdConvData.bcd2 + '0';
	*p++ = '.';
	*p++ = bcdConvData.bcd1 + '0';
	*p++ = bcdConvData.bcd0 + '0';
	*p = '\0';

	return str;
}

// 小数2桁の固定小数点データを7セグ表示用10進形式に変換する
// マイナス時は符号＋3桁表示
void BCD_7seg_conv(int16_t data, uint8_t *bcd)
{
	int8_t sign = 0;
	if(data < 0 ){ 
		data = -data;
		sign =1;
	}
	
	// BCD変換
	BCD_s22_conv(data);
	
	if(sign != 0 && bcdConvData.bcd3 != 0)
	{	// -10A以下
		if(sign==0 && bcdConvData.bcd3 == 0)
		{
			*bcd++ = 11;	// マイナス
			*bcd++ = bcdConvData.bcd3;
			*bcd++ = bcdConvData.bcd2 + 12;
			*bcd = bcdConvData.bcd1;
		}
	}
	else
	{
		if(bcdConvData.bcd3 != 0)
		{
			*bcd++ = bcdConvData.bcd3;
		}
		else
		{
			if(sign==0)
				*bcd++ = 10;	// 空
			else 
				*bcd++ = 11;	// マイナス
		}
		*bcd++ = bcdConvData.bcd2 + 12;
		*bcd++ = bcdConvData.bcd1;
		*bcd = bcdConvData.bcd0;
	}	
}

//==============================================================================
// AD変換
//==============================================================================
// ADC
volatile int32_t addat[2];		// AD変換データ   [0]:電圧 [1]:電流
volatile int16_t adout[2];		// 単位換算後の値 [0]:電圧 [1]:電流

// AD変換処理
// 不可を分散させるため、交互にAD変換＆BCD変換する
// 変換結果は0.01[V,A]単位でsegDataに保存する
// 
void ADC_Drive()
{
	static uint16_t ad_count[2] = 0;
	static int8_t ad_step = 0;

	if(ad_count[0] >= 185)
	{
		// 電圧をBCDへ変換
		addat[0] >>=7;						// 185/128
		adout[0] = addat[0];
		BCD_7seg_conv(adout[0], segData.vd);
		ad_count[0] = 0;
		addat[0] = 0;
		
	}
	else if(ad_count[1] >= 948)
	{
		// 電流をBCDへ変換
		addat[1] += -9089;					// 0点調整
		addat[1] >>=7;						// 948/128
		adout[1] = addat[1];
		BCD_7seg_conv(adout[1], segData.cd);
		ad_count[1] = 0;
		addat[1] = 0;
	}
	else
	{
		// AD変換
		switch(ad_step)
		{
			default:
				// 電圧取得
				addat[0] += ADC_GetConversion(chAN7);
				ad_step = 1;
				ad_count[0]++;
				break;
			case 1:
				// 電流取得
				addat[1] -= (int16_t)ADC_GetConversion(chAN2) - 512;
				ad_step=0;
				ad_count[1]++;
				break;
		}
	}
	
	
}



// 
// タイマルーチン
void TMR_Worker(void)
{
	static uint8_t led_cnt = 0;
	static uint8_t sci_cnt = 0;
	char str[7];
	
	if(TMR2_HasOverflowOccured() != 0)
	{	// タイマ２オーバーフロー
		// インターバル 10ms
		
		// LED点滅
		led_cnt ++;
		if(led_cnt == 50)
		{	// 	1s 周期の点滅
			LED1_Toggle();
			led_cnt = 0;
		}
		
		// シリアル通信でデータを送信する
		// 	0.05sごとに半分ずつ送信
		sci_cnt ++;
		if(sci_cnt == 5)
		{	
			putstr(BCD_s22_str_conv(adout[0],str));
			putstr(",");
			
		}
		if(sci_cnt == 10)
		{	
			putstr(BCD_s22_str_conv(adout[1],str));
			putstr("\r\n");
			sci_cnt = 0;
		}
		
	}
}

/*
                         Main application
 */
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
	I2C_RESET_SetLow();		// I2Cデバイスのリセット(負論理)
	__delay_us(10);
	I2C_RESET_SetHigh();
	MCP17_Initialize();
	// TMR2_SetInterruptHandler(&(TMR_ISR));
	TMR2_StartTimer();
	//TMR2_StopTimer();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

	LED0_Toggle();
	putstr("...START V&C DISP 16F1823\r\n");
	
	// テスト表示データ
	BCD_7seg_conv(1234, segData.vd);
	BCD_7seg_conv(5678, segData.cd);

	// MCP23017 IO設定 -> 全ピン出力
	MCP17REG0.IODIRA = 0x00;
	MCP17REG0.IODIRB = 0x00;
	MCP17_port_status_write();
	
    while (1)
    {
		SEG7_Drive();
		ADC_Drive();
		TMR_Worker();
	}
}
/**
 End of File
*/