//------------------------------------------------------------------------------
// MCP23017
//------------------------------------------------------------------------------
// メモリ使用量削減のため 機能省略
// 出力のみ可能
//

#include "mcc_generated_files/mcc.h"
#include "mcp23017_driver.h"



_mcp17regb0_t MCP17REG0;

#define MCP17_B0_IODIRA	0x00
#define MCP17_B0_IODIRB	0x01
#define MCP17_B0_IOCONA	0x0A
#define MCP17_B0_IOCONB	0x0B
#define MCP17_B0_GPIOA	0x12
#define MCP17_B0_GPIOB	0x13
#define MCP17_B0_OLATA	0x14
#define MCP17_B0_OLATB	0x15

#define MCP17_RETRY_MAX	100			// define the retry count
#define MCP17_ADDRESS	0x20		// slave device address  0b 0100 000

//------------------------------------------------------------------------------
// mcp17 関数
//------------------------------------------------------------------------------

I2C_MESSAGE_STATUS status;
uint8_t     writeBuffer[3];
uint16_t    timeOut;


// 初期化
void MCP17_Initialize()
{
	unsigned char i=0;
	for(i=0;i<sizeof(MCP17REG0.REG)/sizeof(uint8_t);i++)
		MCP17REG0.REG[i] = 0;
	
	// 起動時は入力設定
	MCP17REG0.IODIRA = 0xFF;
	MCP17REG0.IODIRB = 0xFF;
}

//uint8_t *pData = &MCP17REG0.REG[0];
//uint16_t nCount = sizeof(MCP17REG0.REG)/sizeof(uint8_t);

//// IO設定を取得する
//bool MCP17_status_read()
//{
//	status = I2C_MESSAGE_PENDING;
//			
//	// build the write buffer first
//	// starting address of the EEPROM memory
//	writeBuffer[0] = (uint8_t)(0);            // CONTROL REGISTER address
//
//	// Now it is possible that the slave device will be slow.
//	// As a work around on these slaves, the application can
//	// retry sending the transaction
//	timeOut = 0;
//	while(status != I2C_MESSAGE_FAIL)
//	{
//		// write one byte to EEPROM (2 is the count of bytes to write)
//		I2C_MasterWrite( writeBuffer, 1, MCP17_ADDRESS, &status);
//
//		// wait for the message to be sent or status has changed.
//		while(status == I2C_MESSAGE_PENDING) __delay_us(500);
//
//		if (status == I2C_MESSAGE_COMPLETE)
//			break;
//
//		// if status is  I2C_MESSAGE_ADDRESS_NO_ACK,
//		//               or I2C_DATA_NO_ACK,
//		// The device may be busy and needs more time for the last
//		// write so we can retry writing the data, this is why we
//		// use a while loop here
//
//		// check for max retry and skip this byte
//		if (timeOut == MCP17_RETRY_MAX)
//			break;
//		else
//			timeOut++;
//	}
//
//	if (status == I2C_MESSAGE_COMPLETE)
//	{
//
//		// this portion will read the byte from the memory location.
//		timeOut = 0;
//		while(status != I2C_MESSAGE_FAIL)
//		{
//			// write one byte to EEPROM (2 is the count of bytes to write)
//			I2C_MasterRead( pData, nCount, MCP17_ADDRESS, &status);
//
//			// wait for the message to be sent or status has changed.
//			while(status == I2C_MESSAGE_PENDING) __delay_us(500);
//
//			if (status == I2C_MESSAGE_COMPLETE)
//				break;
//
//			// if status is  I2C_MESSAGE_ADDRESS_NO_ACK,
//			//               or I2C_DATA_NO_ACK,
//			// The device may be busy and needs more time for the last
//			// write so we can retry writing the data, this is why we
//			// use a while loop here
//
//			// check for max retry and skip this byte
//			if (timeOut == MCP17_RETRY_MAX)
//				break;
//			else
//				timeOut++;
//		}
//	}
//
//	// exit if the last transaction failed
//	if (status == I2C_MESSAGE_FAIL)
//	{
//		return false;
//	}
//	return true;
//}


void MCP17_2data_write(uint8_t adr, uint8_t data_a, uint8_t data2_b)
{
	writeBuffer[0] = adr;				// CONTROL REGISTER address
	writeBuffer[1] = data_a;			// DIR
	writeBuffer[2] = data2_b;         // DIR

	timeOut = 0;
	status = I2C_MESSAGE_PENDING;
	while(status != I2C_MESSAGE_FAIL)
	{
		// パラメータのアドレスを設定
		I2C_MasterWrite(   writeBuffer, 3, MCP17_ADDRESS, &status);

		// 完了まで待機　delayを入れないとハングする？？
		while(status == I2C_MESSAGE_PENDING) __delay_us(100);

		if (status == I2C_MESSAGE_COMPLETE)
			break;
		
		// タイムアウト確認
		if (timeOut == MCP17_RETRY_MAX)
			break;
		else
			timeOut++;
	}
}


// IOを設定する
void MCP17_port_status_write(void)
{
	MCP17_2data_write(0x00, MCP17REG0.IODIRA, MCP17REG0.IODIRB);
}

// PINデータを送信する
void MCP17_pin_out(void)
{
	MCP17_2data_write(0x14, MCP17REG0.OLATA, MCP17REG0.OLATB);
}
