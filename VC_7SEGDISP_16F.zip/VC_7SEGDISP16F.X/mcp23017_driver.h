/* 
 * File:   mcp23017_driver.h
 * Author: 
 *
 * Created on March 11, 2018, 2:36 PM
 */

#ifndef MCP23017_DRIVER_H
#define	MCP23017_DRIVER_H

#define __MCP23017_SLIM__

#ifdef	__cplusplus
extern "C" {
#endif
typedef union{

	struct{
		union{
			unsigned char IODIRA;		// 0x00
			struct {
				unsigned char IO0:1;
				unsigned char IO1:1;
				unsigned char IO2:1;
				unsigned char IO3:1;
				unsigned char IO4:1;
				unsigned char IO5:1;
				unsigned char IO6:1;
				unsigned char IO7:1;
			}IODIRAbits;
		};
		union{
			unsigned char IODIRB;		// 0x01
			struct {
				unsigned char IO0:1;
				unsigned char IO1:1;
				unsigned char IO2:1;
				unsigned char IO3:1;
				unsigned char IO4:1;
				unsigned char IO5:1;
				unsigned char IO6:1;
				unsigned char IO7:1;
			}IODIRBbits;
		};
#ifndef __MCP23017_SLIM__
		unsigned char IPOLA;		// 0x02
		unsigned char IPOLB;		// 0x03
		unsigned char GPINTENA;	// 0x04
		unsigned char GPINTENB;	// 0x05
		unsigned char DEFVALA;	// 0x06
		unsigned char DEFVALB;	// 0x07
		unsigned char INTCONA;	// 0x08
		unsigned char INTCONB;	// 0x09
		union{
			unsigned char IOCONA;		// 0x0A
			struct {
				unsigned char :1;
				unsigned char INTPOL:1;
				unsigned char ODR:1;
				unsigned char HAEN:1;
				unsigned char DISSLW:1;
				unsigned char SEQOP:1;
				unsigned char MIRROR:1;
				unsigned char BANK:1;
			}IOCONAbits;
		};
		union{
			unsigned char IOCONB;		// 0x0B
			struct {
				unsigned char :1;
				unsigned char INTPOL:1;
				unsigned char ODR:1;
				unsigned char HAEN:1;
				unsigned char DISSLW:1;
				unsigned char SEQOP:1;
				unsigned char MIRROR:1;
				unsigned char BANK:1;
			}IOCONBbits;
		};
		union{
			unsigned char GPPUA;		// 0x0C
			struct {
				unsigned char PU0:1;
				unsigned char PU1:1;
				unsigned char PU2:1;
				unsigned char PU3:1;
				unsigned char PU4:1;
				unsigned char PU5:1;
				unsigned char PU6:1;
				unsigned char PU7:1;
			}GPPUAbits;
		};
		union{
			unsigned char GPPUB;		// 0x0D
			struct {
				unsigned char PU0:1;
				unsigned char PU1:1;
				unsigned char PU2:1;
				unsigned char PU3:1;
				unsigned char PU4:1;
				unsigned char PU5:1;
				unsigned char PU6:1;
				unsigned char PU7:1;
			}GPPUBbits;
		};
		union{
			unsigned char INTFA;		// 0x0E
			struct {
				unsigned char INT0:1;
				unsigned char INT1:1;
				unsigned char INT2:1;
				unsigned char INT3:1;
				unsigned char INT4:1;
				unsigned char INT5:1;
				unsigned char INT6:1;
				unsigned char INT7:1;
			}INTFAbits;
		};
		union{
			unsigned char INTFB;		// 0x0F
			struct {
				unsigned char INT0:1;
				unsigned char INT1:1;
				unsigned char INT2:1;
				unsigned char INT3:1;
				unsigned char INT4:1;
				unsigned char INT5:1;
				unsigned char INT6:1;
				unsigned char INT7:1;
			}INTFBbits;
		};
		union{
			unsigned char INTCAPA;	// 0x10
			struct {
				unsigned char ICP0:1;
				unsigned char ICP1:1;
				unsigned char ICP2:1;
				unsigned char ICP3:1;
				unsigned char ICP4:1;
				unsigned char ICP5:1;
				unsigned char ICP6:1;
				unsigned char ICP7:1;
			}INTCAPAbits;
		};
		union{
			unsigned char INTCAPB;	// 0x11
			struct {
				unsigned char ICP0:1;
				unsigned char ICP1:1;
				unsigned char ICP2:1;
				unsigned char ICP3:1;
				unsigned char ICP4:1;
				unsigned char ICP5:1;
				unsigned char ICP6:1;
				unsigned char ICP7:1;
			}INTCAPBbits;
		};
		union{
			unsigned char GPIOA;		// 0x12
			struct {
				unsigned char GP0:1;
				unsigned char GP1:1;
				unsigned char GP2:1;
				unsigned char GP3:1;
				unsigned char GP4:1;
				unsigned char GP5:1;
				unsigned char GP6:1;
				unsigned char GP7:1;
			}GPIOAbits;
		};
		union{
			unsigned char GPIOB;		// 0x13
			struct {
				unsigned char GP0:1;
				unsigned char GP1:1;
				unsigned char GP2:1;
				unsigned char GP3:1;
				unsigned char GP4:1;
				unsigned char GP5:1;
				unsigned char GP6:1;
				unsigned char GP7:1;
			}GPIOBbits;
		};
		
#endif
		union{
			unsigned char OLATA;		// 0x14
			struct {
				unsigned char OL0:1;
				unsigned char OL1:1;
				unsigned char OL2:1;
				unsigned char OL3:1;
				unsigned char OL4:1;
				unsigned char OL5:1;
				unsigned char OL6:1;
				unsigned char OL7:1;
			}OLATAbits;
		};
		union{
			unsigned char OLATB;		// 0x15
			struct {
				unsigned char OL0:1;
				unsigned char OL1:1;
				unsigned char OL2:1;
				unsigned char OL3:1;
				unsigned char OL4:1;
				unsigned char OL5:1;
				unsigned char OL6:1;
				unsigned char OL7:1;
			}OLATBbits;
		};
	};
#ifndef __MCP23017_SLIM__
	unsigned char REG[22];
#else
	unsigned char REG[4];
#endif
	
	
}_mcp17regb0_t;

extern _mcp17regb0_t MCP17REG0;




//------------------------------------------------------------------------------
//mcp17 関数
//------------------------------------------------------------------------------
// 初期化
extern void MCP17_Initialize();
//
//// IO設定を設定する
//extern bool MCP17_status_read();

// IOを設定する
extern void MCP17_port_status_write(void);

extern void MCP17_pin_out(void);

#ifdef	__cplusplus
}
#endif

#endif	/* MCP23017_DRIVER_H */

